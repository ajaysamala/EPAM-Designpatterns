package BuilderPattern;

public abstract  class chocolate implements Packing {
    public abstract String pack();
}
